const express = require("express");
const Assignment = require("../models/Assignment");
const protect = require("../middleware/auth");

const router = express.Router();


router.post("/",  async(req, res)=>{
    try {
        const {title, description, dueDate} = req.body;

        const assignment = await Assignment.create({
            title,
            description,
            dueDate,
            createdBy: req.user._id
        });

        res.status(201).json(assignment);
    } catch(err) {
        res.status(500).json({message: err.message})
    }
});

router.get("/", async(req, res)=>{
    try {
        const assignment = await Assignment.find()
        .populate("createdBy", "name email");

        res.json(assignment);
    } catch(err) {
        return res
        .status(500)
        .json({massage:err.massage});
    }
});

router.delete("/:id", async (req, res)=>{
    try {
         const assignment = await Assignment.findById(req.params.id);

        if(!assignment){
            return res.status(404).json({massage: "Assignment not found"});
        }
        
        await assignment.deleteOne();
        res.json({massage:"Assignment deleted successfully"});

    } catch(err){
        return res.status(500).json({message:err.message});
    }
});

module.exports = router;