const express = require("express");
const Submission = require("../models/Submission");
const Assignment = require ("../models/Assignment");
const {protect} = require ("../middleware/auth");

const router = express.Router();

router.post("/",   async(req, res)=>{
    try {
        const {assignmentId, content} = req.body;
        
        const assignment = await Assignment.findById(assignmentId);
        if(!assignment) {
            return res.status(404).json({message: "Assignment not found"});
        }
    
    if (new Date() > assignment.dueDate){
        return res.status(400).json({message:"Deadline as pass"});
    }
    
    const alreadySubmitted = await Submission.findOne({
        assignment: assignmentId,
        student:req.user._id
    });

    if (alreadySubmitted){
        return res.status(400).json({message:"You already submitted"});
    }
    
    const submission = await Submission.create({
        assignment: assignmentId,
        student: req.user._id,
        content
    });

    res.status(201).json(submission);
} catch (err){
    res.status(500).json({massage: err.message});
}
});

router.get("/:assigmentId",  async(req, res)=>{
    try{
        const submission = await Submission.find({
            assignment: req.params.assigmentId
        })
        .populate("student", "name email")
        .populate("assignment","title");

        res.json(submission);
    } catch (err){
        return res.status(500).json({massage: err.massage});
    }
});

router.get("/my-submission", async(req,res)=>{
    try{
        const submission = await Submission.find({
            student: req.user._id
        })
        .poupulate("assignment", "title description dueDate");

        res.json(submission);
    } catch (err){
        return res.status(500).json({massage: err.massage});
    }
});

module.exports = router;
