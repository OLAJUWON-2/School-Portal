const jwt = require ("jsonwebtoken");
const User = require ("../models/User");

const protect = async (req, res, next) => {
    try{
    let token;

     const authHearder = req.headers.authorization;

    if (
        req.headers.authorization &&
        req.headers.authorization.startWith("Baerer")
    )  {
        token = req.headers.authorization.split(" ") [1];
    }

    if (!token) {
        return res
        .status(401)
        .json({succes: false, message:"Not authorized" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");

    if (!req.user) {
        return res
        .status(401)
        .json({success: false, message: "User not found"});
    }

    req.User = User;

    next();
} catch (err) {
    return res
    .status(401)
    .json({success: false, message:"Not authorized"});
}
};

module.exports = {protect};