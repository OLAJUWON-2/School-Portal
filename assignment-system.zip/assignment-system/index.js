require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require ("cors");


const submissionRoutes = require("./routes/submission");
const authRoutes = require ("./routes/auth");
const assignmentRoutes = require ("./routes/assignment");
const app = express();
const PORT = process.env.PORT || 5000;



app.use(cors());
app.use(express.json());

app.use("/api/submission", submissionRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/assignment",assignmentRoutes);

app.get("/", (req, res)=>{
    res.send("API is running...");
});

mongoose 
    .connect(process.env.MONGODB_URI)
    .then(()=>{
        console.log("MongoDB Connected");
        app.listen(PORT, ()=>
        console.log('server running at http://localhost:${PORT}')
        );
    })
    .catch((err)=>{
        console.error("MongoDB connection error:", err.massage);
        process.exit(1);
    })