const mongoose = require("mongoose");

const assignmentSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim:true
     },

     description:{
        type: String,
        required: true,
        trim: true
     },
     dueDate: {
        type: Date,
        required: true,
        trim: true
     },

     createdBy:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
     }

}, {timestamps:true});

assignmentSchema.index({title:"text", description: "text"});

module.exports = mongoose.model("Assignment", assignmentSchema);