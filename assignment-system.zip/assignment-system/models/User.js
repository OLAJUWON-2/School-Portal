const mongoose = require ("mongoose");
const bcrypt = require ("bcryptjs");


const userSchema = new mongoose.Schema(
    {
        name:{
            type: String,
            required: [true, "Name is require"],
            trim: true,
        },

        email:{
            type: String,
            required: [true, "Email is require"],
            unique: true,
            lowercase: true,
            trim: true,
        },

        password:{
            type: String,
            required: [true, "password is required"],
            minlength: 6,
        },

        role:{
            type: String,
            enum: ["teacher", "student"],
            default: "student",
        },
    },

    {timestamps: true}
);


userSchema.pre("save", async function (next){
  if (!this.isModified ("password")) return next();
  const salt = await bcrypt.genSalt (10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});


userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model("User", userSchema);