const mongoose = require("mongoose");

const submissionSchema = new mongoose.Schema({
    assignment:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"Assignment",
        required: true,
        trim: true
     },

     student:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
        trim: true
     },

     content:{
        type: String,
        required: true,
        trim: true
     },

     submittedAt:{
      type: Date,
      default: Date.now
     }
}, {timestamps: true});

module.exports = mongoose.model("Submission", submissionSchema);